#include<conio.h>
#include<stdio.h>
void main()
{
int i;
clrscr();
for(i=0;i<=127;i++)
{
printf("ASCII value of +ve int is %c",i,i);
getch();
}
getch();
}
