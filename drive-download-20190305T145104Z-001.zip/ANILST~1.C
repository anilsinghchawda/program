#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void  push();
void read();
void pop();

    int a[50];
    int top=-1;
void main()
{
    int ch;
    clrscr();
  while(1)

    {
    printf("\n1) Insert element in stack\n");
    printf("2)Reading elements from top of stack\n");
    printf("3)Remove element from stack\n");
    printf("4) Exist\n");
    printf("\nEnter your choice=");
    scanf("%d",&ch);
    switch(ch)
    {
    case 1:
	push();
	break;
    case 2:
	read();
	break;
    case 3:
	pop();
	break;
    case 4:
	exit(0);
	default:printf("Incorrect choice\n");
    }
}
getch();
}
void push()
{
    int v;
    printf("\n\nEnter the value for insertion=");
    scanf("%d",&v);
    //int a[top];
    if(top==-1)
    {
        top=0;
        a[top]=v;
    printf("%d is added to stack\n",a[top]);
    }
    else
    {
	top++;
	a[top]=v;

    printf("%d is added to stack\n",a[top]);
    }
}
void read()
{
    int i;
    if (top==-1)
	printf("Stack is empty\n");
    else
    {
    for (i=top;i>=0;i--)
    {
        printf("The elements of stack are=%d\n",a[i]);
    }

    }
}
void pop()
{
    if (top==-1)
    {
        printf("Sorry,Stack is empty\nTry another (push) function\n");
    }
    else
    {
        int store=a[top];
        top--;
        printf("The deleted element is %d",store);
    }
}
