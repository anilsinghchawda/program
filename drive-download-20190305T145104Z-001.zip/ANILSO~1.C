#include<stdio.h>
#include<conio.h>
 void main()
{
    int a[20];
    int b,k,i,j,l,c;
    clrscr();
    printf("Enter the size of array\n");
    scanf("%d",&b);
    printf("Enter the element of array=\n");
    for (j=0;j<b;j++)
    {
    scanf("%d\n",&a[j]);
    }
    for(i=0;i<b;i++)
    {
    for (k=0;k<b-i;k++)
    {
	if (a[k]>a[k+1])
	{
	  c=a[k+1];
	  a[k+1]=a[k];
	  a[k]=c;
	}
	}
	}
	printf("Sorted array is=\n");
	for (l=0;l<b;l++)
	{
	printf("%d\n",a[l]);
	}
    getch();
}


